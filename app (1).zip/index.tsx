
import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';

const App = () => {
    const [openSection, setOpenSection] = useState('summary');

    const toggleSection = (section) => {
        setOpenSection(openSection === section ? null : section);
    };

    const colors = {
        primary: '#00539F', // Atturra Blue
        secondary: '#00A9E0', // Lighter Blue
        accent: '#FF671F', // Action Orange
        text: '#333333',
        lightText: '#666666',
        bg: '#FFFFFF',
        lightBg: '#F7F9FA',
        border: '#E0E0E0'
    };
    
    const icons = {
        summary: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>,
        drivers: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path><line x1="4" y1="22" x2="4" y2="15"></line></svg>,
        challenges: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>,
        objectives: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="6"></circle><circle cx="12" cy="12" r="2"></circle></svg>,
        approach: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>,
        why: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>,
        chevron: <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>,
    };

    const Section = ({ id, title, icon, children }) => (
        <div className="section">
            <button className="section-header" onClick={() => toggleSection(id)} aria-expanded={openSection === id}>
                <div className="section-header-left">
                    {icon}
                    <h3>{title}</h3>
                </div>
                <span className={`chevron ${openSection === id ? 'open' : ''}`}>{icons.chevron}</span>
            </button>
            <div className={`section-content ${openSection === id ? 'open' : ''}`}>
                <div className="section-content-inner">
                    {children}
                </div>
            </div>
        </div>
    );

    const CallToAction = ({ text, href, primary = false }) => (
        <a href={href || '#'} className={`cta-button ${primary ? 'primary' : ''}`} target="_blank" rel="noopener noreferrer">
            {text} &rarr;
        </a>
    );

    return (
        <>
            <style>{`
                :root {
                    --primary: ${colors.primary};
                    --secondary: ${colors.secondary};
                    --accent: ${colors.accent};
                    --text: ${colors.text};
                    --light-text: ${colors.lightText};
                    --bg: ${colors.bg};
                    --light-bg: ${colors.lightBg};
                    --border: ${colors.border};
                    --shadow: 0 4px 6px rgba(0,0,0,0.05);
                    --shadow-lg: 0 10px 15px rgba(0,0,0,0.07);
                }
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                    background-color: var(--light-bg);
                    color: var(--text);
                    line-height: 1.6;
                }
                .container {
                    max-width: 900px;
                    margin: 0 auto;
                    padding: 1.5rem;
                }
                .header {
                    text-align: center;
                    padding: 2rem 0 3rem;
                    border-bottom: 1px solid var(--border);
                    margin-bottom: 2rem;
                }
                .header .logos {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    gap: 1rem;
                    margin-bottom: 1rem;
                }
                .header .logos span {
                    font-size: 1.5rem;
                    color: var(--light-text);
                }
                .header .logo {
                    font-weight: bold;
                    font-size: 1.5rem;
                    padding: 0.5rem 1rem;
                    border-radius: 8px;
                }
                .header .woolies-logo {
                    color: #178841; /* Woolies Green */
                    border: 1px solid #178841;
                }
                .header .atturra-logo {
                    color: var(--primary);
                    border: 1px solid var(--primary);
                }
                .header h1 {
                    font-size: 2rem;
                    font-weight: 700;
                    color: var(--text);
                    margin-bottom: 0.5rem;
                }
                .header p {
                    font-size: 1.1rem;
                    color: var(--light-text);
                    max-width: 700px;
                    margin: 0 auto;
                }
                
                .section {
                    background-color: var(--bg);
                    border-radius: 12px;
                    margin-bottom: 1rem;
                    box-shadow: var(--shadow);
                    overflow: hidden;
                    transition: all 0.3s ease-in-out;
                }
                .section:hover {
                    box-shadow: var(--shadow-lg);
                }
                .section-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    width: 100%;
                    padding: 1.25rem 1.5rem;
                    background: none;
                    border: none;
                    text-align: left;
                    cursor: pointer;
                    font-size: 1rem;
                }
                .section-header-left {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    color: var(--primary);
                }
                .section-header h3 {
                    font-size: 1.25rem;
                    font-weight: 600;
                    color: var(--primary);
                }
                .chevron {
                    transition: transform 0.3s ease;
                    color: var(--secondary);
                }
                .chevron.open {
                    transform: rotate(180deg);
                }
                
                .section-content {
                    max-height: 0;
                    overflow: hidden;
                    transition: max-height 0.5s ease-in-out;
                }
                .section-content.open {
                    max-height: 2000px; /* Adjust as needed */
                }
                .section-content-inner {
                    padding: 0 1.5rem 1.5rem 1.5rem;
                    border-top: 1px solid var(--border);
                }
                .section-content-inner p, .section-content-inner ul {
                    margin-bottom: 1rem;
                    color: var(--light-text);
                }
                .section-content-inner h4 {
                    font-size: 1.1rem;
                    font-weight: 600;
                    color: var(--text);
                    margin-top: 1.5rem;
                    margin-bottom: 0.5rem;
                }
                .section-content-inner ul {
                    list-style-position: inside;
                    padding-left: 0.5rem;
                }
                .section-content-inner li {
                    margin-bottom: 0.5rem;
                }
                .section-content-inner strong {
                    color: var(--text);
                    font-weight: 600;
                }

                .cta-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 1rem;
                    margin-top: 1.5rem;
                }

                .cta-button {
                    display: inline-block;
                    text-decoration: none;
                    padding: 0.75rem 1.5rem;
                    border-radius: 8px;
                    font-weight: 600;
                    text-align: center;
                    transition: all 0.2s ease;
                    border: 2px solid var(--accent);
                    color: var(--accent);
                    background-color: var(--bg);
                }
                .cta-button:hover {
                    background-color: var(--accent);
                    color: var(--bg);
                    transform: translateY(-2px);
                    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                }
                .cta-button.primary {
                    background-color: var(--accent);
                    color: var(--bg);
                }
                .cta-button.primary:hover {
                    background-color: #e65c19; /* Darker accent */
                    border-color: #e65c19;
                }

                .footer {
                    text-align: center;
                    padding: 3rem 1rem;
                    margin-top: 2rem;
                }
                .footer h2 {
                    font-size: 1.75rem;
                    margin-bottom: 1rem;
                }
                .footer p {
                    color: var(--light-text);
                    margin-bottom: 1.5rem;
                }

                @media (max-width: 768px) {
                    .container {
                        padding: 1rem;
                    }
                    .header h1 {
                        font-size: 1.75rem;
                    }
                    .header p {
                        font-size: 1rem;
                    }
                    .section-header h3 {
                        font-size: 1.1rem;
                    }
                }
            `}</style>
            <div className="container">
                <header className="header">
                    <div className="logos">
                        <span className="logo woolies-logo">Woolworths Group</span>
                        <span className="plus">+</span>
                        <span className="logo atturra-logo">Atturra</span>
                    </div>
                    <h1>HR & Integration Transformation</h1>
                    <p>A strategic proposal for modernising Woolworths' technology landscape and empowering your workforce.</p>
                </header>

                <main>
                    <Section id="summary" title="Executive Summary" icon={icons.summary}>
                        <p>Woolworths Group is poised for a strategic HR transformation, moving from SAP SuccessFactors to Workday. This shift aims to resolve significant user experience challenges, rectify systemic data fragmentation, and proactively address future regulatory demands. A parallel goal is to elevate Dell Boomi from a tactical tool to a strategic, governed integration backbone.</p>
                        <p>Success requires a phased, de-risked approach with a strong emphasis on change management, observability, and sustainable governance. Atturra is positioned as the ideal partner to navigate this complexity, ensuring the new technology ecosystem delivers lasting value, enhances employee experience, and provides a resilient foundation for future growth.</p>
                    </Section>
                    
                    <Section id="drivers" title="Business Drivers" icon={icons.drivers}>
                        <h4>Enhance Employee & Manager Experience</h4>
                        <p>Transition from a system described as "clunky and unintuitive" to the modern, user-friendly Workday platform, which has been noted as a better cultural fit—"more Woolies."</p>
                        <h4>Improve Operational Agility</h4>
                        <p>Reduce dependency on external support for routine system configurations and workflow updates, empowering internal teams to respond faster to business needs.</p>
                        <h4>Drive Value from Technology Investment</h4>
                        <p>Move beyond the current platform's "ceiling in terms of value realisation" to unlock the full potential of a modern, integrated HR solution with embedded analytics.</p>
                        <h4>Future-Proof HR for Regulatory Change</h4>
                        <p>Build a flexible, auditable system ready to handle upcoming complexities such as Fair Work reforms and Right to Disconnect legislation.</p>
                    </Section>

                    <Section id="challenges" title="Current State Challenges" icon={icons.challenges}>
                        <h4>Platform & User Engagement Limitations</h4>
                        <p>The current SuccessFactors platform is perceived as outdated and difficult to manage, leading to low engagement, particularly from field teams who find it resembles "admin tools from 2008."</p>
                        <h4>Severe Data Fragmentation</h4>
                        <p>The data landscape is "messy and fragile," with no canonical source of employee data. This creates significant issues in managing lifecycle changes and ensuring data consistency across the group.</p>
                        <h4>Immature & Risky Integration Landscape</h4>
                        <p>Dell Boomi has been used tactically, resulting in over 30 point-to-point, often undocumented integrations. This creates "invisible fragility," where process failures can occur silently without notification.</p>
                        <h4>Operational & Knowledge Gaps</h4>
                        <p>A lack of operational visibility, standardised design patterns, and documented runbooks creates a high-risk dependency on a small number of key individuals.</p>
                         <div className="cta-grid">
                           <CallToAction text="Download Migration Readiness Checklist" href="#" />
                        </div>
                    </Section>

                    <Section id="objectives" title="Strategic Objectives & Future State" icon={icons.objectives}>
                        <h4>A Unified, Modern HR Platform</h4>
                        <p>Implement Workday as the single source of truth for all employee data, providing a superior user experience and powerful, accessible analytics for data-driven decision-making.</p>
                        <h4>A Strategic Integration Backbone</h4>
                        <p>Elevate Dell Boomi to a governed, strategic asset. Develop reusable templates, introduce event-driven architectures, and ensure robust API management to create a resilient "backbone of how data moves across Woolworths."</p>
                        <h4>An Observable & Sustainable Ecosystem</h4>
                        <p>Engineer integration observability from day one, including centralised monitoring, SLA tracking, and automated alerts. Establish a lightweight Integration Centre of Excellence (CoE) to ensure governance, standardisation, and knowledge sharing.</p>
                        <h4>User Adoption Driven by People</h4>
                        <p>Deliver a "Woolworths initiative, not an IT project." Drive high engagement through intentional change leadership, persona-based training, co-design workshops, and a network of internal super-users.</p>
                    </Section>
                    
                    <Section id="approach" title="Recommended Approach & Next Steps" icon={icons.approach}>
                        <p>We propose a collaborative, phased approach designed to build momentum, de-risk complexity, and ensure value at every stage.</p>
                        <h4>Phase 1: Foundation & Governance (Weeks 1-4)</h4>
                        <ul>
                            <li><strong>Integration Deep-Dive Workshop:</strong> Align on Boomi industrialisation, design patterns, and governance frameworks.</li>
                            <li><strong>CoE Charter Definition:</strong> Jointly establish the charter, roles, and responsibilities for the new Integration CoE.</li>
                            <li><strong>Phased Rollout & Change Impact Analysis:</strong> Develop a detailed Workday migration plan with clear stage gates and a robust contingency strategy.</li>
                        </ul>
                        <h4>Phase 2: Core Implementation & Integration (Month 2-6)</h4>
                        <ul>
                            <li><strong>Build Foundational Templates:</strong> Develop reusable, observable integration assets in Boomi for high-value use cases (e.g., Onboarding, Payroll Sync).</li>
                            <li><strong>Workday Phased Go-Live:</strong> Execute the first stage of the Workday rollout, running in parallel with legacy systems to ensure a seamless transition.</li>
                        </ul>
                         <h4>Phase 3: Embed & Empower (Month 7+)</h4>
                        <ul>
                            <li><strong>Execute Change Program:</strong> Roll out co-designed training, communications, and support structures.</li>
                            <li><strong>Establish Super-User Network:</strong> Activate and empower business champions to drive adoption from within.</li>
                            <li><strong>Full Handover & Sustainment:</strong> Transition operational ownership to the Woolworths team, supported by comprehensive runbooks and a co-managed CoE.</li>
                        </ul>
                        <div className="cta-grid">
                            <CallToAction text="View a Workday Integration Success Story" href="#" />
                        </div>
                    </Section>

                    <Section id="why" title="Why Atturra?" icon={icons.why}>
                        <p>We believe partnership is more than just delivery. It's about shared outcomes and building lasting capability.</p>
                        <ul>
                            <li><strong>Dual Expertise:</strong> Deep, certified specialisation in both Workday transformation and the industrialisation of Dell Boomi integration platforms.</li>
                            <li><strong>Proven De-risking Frameworks:</strong> Our methodology is built on years of experience navigating complex enterprise HR and integration projects. We know where the risks are and how to mitigate them.</li>
                            <li><strong>Focus on Enablement:</strong> We don't just build and leave. Our goal is to co-create a sustainable ecosystem and empower your teams through a co-managed CoE, comprehensive documentation, and hands-on knowledge transfer.</li>
                            <li><strong>Change Management at the Core:</strong> We understand that technology is only successful if people use it. Our embedded change and adoption practice ensures your investment translates into real behavioural change and business value.</li>
                        </ul>
                    </Section>
                </main>
                <footer className="footer">
                    <h2>Ready for the Next Step?</h2>
                    <p>Let's schedule a follow-up workshop to dive deeper into our proposed approach and define the Integration CoE charter.</p>
                    <CallToAction text="Book a Follow-up Workshop" primary={true} href="#" />
                </footer>
            </div>
        </>
    );
};

const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App />);